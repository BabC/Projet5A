//Creation of an application not needed to bind it to a global variable
angular.module('adminApp',['factoryServices']);