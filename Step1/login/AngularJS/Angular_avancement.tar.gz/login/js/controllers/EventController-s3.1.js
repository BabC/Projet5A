angular.module('adminApp').controller('eventCtrl',eventCrtFnt);

eventCrtFnt.$inject=['$scope', 'factory', '$window'];

function eventCrtFnt($scope, factory, $window){
  
  $scope.currentPresenation = factory.presentationCreation(currentPresenation.title,"description");
  
  $scope.newSlide = function(){ 
    
    var lContent = factory.contentCreation(currentPresenation.title,"type","src");
    
    var lSlide = factory.slidCreation(currentPresenation.title,"txt");
    lSlide.contentMap.push(lContent);
    
    $scope.currentPresenation.slidArray.push(lSlide);
    
  };
  
}