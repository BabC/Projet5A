angular.module('loginApp').controller('loginCtrl',loginCrtFnt);

loginCrtFnt.$inject=['$scope','$log','auth','$window'];

function loginCrtFnt($scope,$log,auth,$window){
  
  $scope.logAuth=function(){
    $log.info('user login',$scope.user.login);
    $log.info('user pwd',$scope.user.pwd);
  };  
  
  $scope.logAuthObject=function(user){
    
    if(user != null)
    {
      var Authentification = auth.localAuthAsk(user.login,user.pwd);
      Authentification.then(
	
	function(payload){
	  
	  $log.info('user login',payload.login);
	  $log.info('user pwd',payload.validAuth);
	  $log.info('user pwd',payload.role);
	  
	  var href = payload.role + '.html'
	  
	  $window.location.href = href;
	  
	},
	
	function(errorPayload){
	  $log.info(errorPayload);
	}
      );
    }
    
    
    
  };
  
  
}