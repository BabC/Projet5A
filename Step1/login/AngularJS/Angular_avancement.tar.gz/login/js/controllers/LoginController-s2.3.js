angular.module('loginApp').controller('loginCtrl',loginCrtFnt);

loginCrtFnt.$inject=['$scope','$log','auth','$window'];

function loginCrtFnt($scope,$log,auth,$window){
  
  $scope.logAuth=function(){
    $log.info('user login',$scope.user.login);
    $log.info('user pwd',$scope.user.pwd);
  };  
  
  $scope.logAuthObject=function(user){
    
    if(user != null)
    {
      var Authentification = auth.authAsk(user.login,user.pwd);
      Authentification.then(
	
	function(payload){
	  
	  var href = payload.role + '.html'
	  
	  $window.location.href = href;
	  
	},
	
	function(errorPayload){
	  $log.info(errorPayload);
	}
      );
    }
    
    
    
  };
  
  
}