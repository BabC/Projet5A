angular.module('authService',[]).service('auth',authFnc);  //Création dans le module 'authService' le service 'auth'

authFnc.$inject=['$http', '$q'];

function authFnc($http,$q){
  
  var userMap={};
  userMap['admin']='admin';
  userMap['jdoe']='jdoepwd';
  userMap['psmith']='psmithpwd';
  userMap['tp']='tp';
  
  var templateUser={
    'login':'',
    'validAuth':false,
    'role':''
  };
  
  var fncContainer={
    localAuthAsk:localAuthAsk
  };
  
  function localAuthAsk(login,pwd){
    var deferred=$q.defer();
    setInterval(function(login,pwd)
    {
      if(userMap[login]==pwd)
      {
	var infoUser = templateUser;
	
	infoUser.login = login;
	infoUser.validAuth = true;
	if(infoUser.login == "admin")
	{
	  infoUser.role = "admin";
	}
	else
	{
	  infoUser.role = "watch";
	}
	deferred.resolve(infoUser);
	
      }
      else
      {
	  deferred.reject("Erreur dans les informations");
      }
      clearInterval(this);
    },3000,login,pwd);
  
    return deferred.promise;
  }
  
  return fncContainer;
  
}