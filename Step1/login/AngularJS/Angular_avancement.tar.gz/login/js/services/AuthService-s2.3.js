angular.module('authService',[]).service('auth',authFnc);  //Création dans le module 'authService' le service 'auth'

authFnc.$inject=['$http', '$q'];

function authFnc($http,$q){
  
  var userMap={};
  userMap['admin']='admin';
  userMap['jdoe']='jdoepwd';
  userMap['psmith']='psmithpwd';
  userMap['tp']='tp';
  
  var templateUser={
    'login':'',
    'validAuth':false,
    'role':''
  };
  
  var fncContainer={
    localAuthAsk:localAuthAsk
  };
  
  function authAsk(login,pwd){
    var deferred=$q.defer();
    $http.post('/fakeauthwatcher',{'login':login,'pwd':pwd});
	
	success(function(data,status,headers,config){
	  
	  deferred.resolve(data);
	  
	});
	
	error(function(data,status,headers,config){
	  
	  deferred.reject(status);
	  
	});

	
    return deferred.promise;
  }
  
  return fncContainer;
  
}