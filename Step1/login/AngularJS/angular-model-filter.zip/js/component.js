var app=angular.module('MyApp',[]);

app.controller('myControl',function(){
    
    this.unitsList=starShipsList;
    this.searchTxt='Enter your filter option';
    
});