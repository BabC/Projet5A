var pagmShip={  name: {    nickname:'pagme Starship',
	       fullname:'Naboo Royal Starship'      },
	   location: 'Naboo',
	   length:76
	   };
var corvetteShip={  name: {  nickname:' Corvette',
	       fullname:'CR70 corvette'         },
	   location: 'Corellian Engineering Corporation',
	   length:150
	   };
var finisherShip={  name: {  nickname:' finisher',
	       fullname:'C10 finisher'         },
	   location: 'CORIBAN',
	   length:100
	   };
var BlackStar={  name: {  nickname:' BlackStar',
	       fullname:'BS457820'         },
	   location: 'Unknown',
	   length:150000000000000000
	   };


var starShipsList=[pagmShip,corvetteShip,finisherShip,BlackStar];







